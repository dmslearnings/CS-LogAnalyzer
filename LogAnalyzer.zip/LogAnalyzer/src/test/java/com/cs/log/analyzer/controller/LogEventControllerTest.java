package com.cs.log.analyzer.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.web.servlet.MockMvc;
import com.cs.log.analyzer.modal.Event;
import com.cs.log.analyzer.service.LogEventService;


@WebMvcTest(value = LogEventController.class)
public class LogEventControllerTest {

    @LocalServerPort
    int randomServerPort;
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private LogEventService logEventService;
	
	Event event1 =  new Event.Builder("testId1")
	           .withHost("testhost1")
	           .withType("testtype1")
	           .withDuration(4)
	           .withAlert(false)
	           .build();
	
	Event event2 =  new Event.Builder("testId2")
	           .withHost("testhost2")
	           .withType("testtype2")
	           .withDuration(5)
	           .withAlert(true)
	           .build();
	
	
	@Test
	public void getEventByIdTest() throws Exception {
		
		Mockito.when(logEventService.getEventById(Mockito.anyString())).thenReturn(Optional.of(event1));

		String expected = "{id:testId1,host:testhost1,type:testtype1,duration:4,alert:false}";

		this.mockMvc.perform(get("/events/testId")).andDo(print()).andExpect(status().isOk())
		.andExpect(content().json(expected));
	}
	
	@Test
	public void getAllEventTest() throws Exception {
		
		List<Event> eventList = new ArrayList();
		eventList.add(event1);
		eventList.add(event2);
		
		Mockito.when(logEventService.getEvents()).thenReturn(eventList);

		String expected = "{id:testId1,host:testhost1,type:testtype1,duration:4,alert:false}";

		this.mockMvc.perform(get("/events")).andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	public void getAllFlaggedEventTest() throws Exception {
		
		List<Event> eventList = new ArrayList();

		eventList.add(event2);
		
		Mockito.when(logEventService.getFlaggedEvents()).thenReturn(eventList);

		String expected = "[{id:testId2,host:testhost2,type:testtype2,duration:5,alert:true}]";

		this.mockMvc.perform(get("/events/flagged")).andDo(print()).andExpect(status().isOk()).andExpect(content().json(expected));
	}
		
	
}
