package com.cs.log.analyzer.service;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cs.log.analyzer.modal.Event;
import com.cs.log.analyzer.repository.LogEventRepository;

@ExtendWith(MockitoExtension.class)
public class LogEventServiceTest {
	
	@Mock
	LogEventRepository logEventRepository;
	
    @InjectMocks
    LogEventService logEventService;
    
    @Mock
    Event mockEvent;
	
	Event event1 =  new Event.Builder("testId1")
	           .withHost("testhost1")
	           .withType("testtype1")
	           .withDuration(4)
	           .withAlert(false)
	           .build();
	
	Event event2 =  new Event.Builder("testId2")
	           .withHost("testhost2")
	           .withType("testtype2")
	           .withDuration(5)
	           .withAlert(true)
	           .build();
	
	
	@Test
	public void getEventByIdTest() throws Exception {
		
		Mockito.when(logEventRepository.findById(Mockito.anyString())).thenReturn(Optional.of(event1));

       Assertions.assertEquals(logEventService.getEventById("testId1"), Optional.of(event1));
	}
	
	@Test
	public void getAllEventTest() throws Exception {
		
		List<Event> eventList = new ArrayList();
		eventList.add(event1);
		eventList.add(event2);
		
		Mockito.when(logEventRepository.findAll()).thenReturn(eventList);

		 Assertions.assertEquals(logEventService.getEvents(), eventList);
	}
	
	@Test
	public void getAllFlaggedEventTest() throws Exception {
		
		List<Event> eventList = new ArrayList();

		eventList.add(event2);
		
		Mockito.when(logEventRepository.findByAlertValue(Mockito.anyBoolean())).thenReturn(eventList);
		Assertions.assertEquals(logEventService.getFlaggedEvents(), eventList);
	}
	
	@Test
	public void parseEventAndSaveToDbTest() throws URISyntaxException
	{
		URL res = getClass().getClassLoader().getResource("logfile.txt");
		File file = Paths.get(res.toURI()).toFile();
		String absolutePath = file.getAbsolutePath();
		Assertions.assertTrue(logEventService.parseEventsAndSaveToDb(absolutePath));
		
	}
	
	@Test
	public void parseEventAndSaveToDbFalseTest()
	{

		Assertions.assertFalse(logEventService.parseEventsAndSaveToDb("invalid"));
		
	}

}
