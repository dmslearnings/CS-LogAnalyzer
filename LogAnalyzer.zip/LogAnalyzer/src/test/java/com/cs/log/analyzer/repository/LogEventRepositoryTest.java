package com.cs.log.analyzer.repository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.cs.log.analyzer.modal.Event;

@DataJpaTest
public class LogEventRepositoryTest {
	
	@Autowired
    LogEventRepository logEventRepository;
	
	@Test
	public void testFindByAlertValue() {
		
		Event event2 =  new Event.Builder("testId2")
		           .withHost("testhost2")
		           .withType("testtype2")
		           .withDuration(5)
		           .withAlert(true)
		           .build();
		
		logEventRepository.save(event2);		
		Assertions.assertNotNull(logEventRepository.findByAlertValue(true));
		
	}

}
