package com.cs.log.analyzer.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cs.log.analyzer.modal.Event;
import com.cs.log.analyzer.modal.Logs;
import com.cs.log.analyzer.repository.LogEventRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LogEventService {
	
	private Map<String, List<Logs>> map=null;
	private ObjectMapper mapper =null;
	
	@Autowired
	private LogEventRepository repository;
	
	@Value("${log.time.diff.value:4}")
	int logTimeDiff;
	
	public Optional<Event> getLogEventById(String id) {
		
		return repository.findById(id);
	}
	
	public List<Event> getLogEvents(){
		
		return repository.findAll();
	}
	
	public List<Event> getFlaggedLogEvents(){
		
		return repository.findByAlertValue(true);
	}
	
	public boolean parseLogAndPersistToDb(String path) {
		
		try (Stream<String> lines = (Files.lines(Paths.get(path)))) {
			map = new ConcurrentHashMap<>();
			mapper = new ObjectMapper();
			lines.parallel().forEach((currentLine) -> {

				try {
					Logs logEntry = mapper.readValue(currentLine, Logs.class);
					
					log.debug("received logEntry: {}", logEntry);

					if (!map.containsKey(logEntry.getId())) 
					{
						List<Logs> list = new LinkedList<>();
						list.add(logEntry);
						map.putIfAbsent(logEntry.getId(), list);
					} else 	{						
						Logs LogFinish = map.get(logEntry.getId()).get(0);
						long duration = Math.abs(LogFinish.getTimestamp() - logEntry.getTimestamp());
						boolean alert = duration > logTimeDiff ? true : false;
						Event event = new Event.Builder(logEntry.getId())
								           .withHost(logEntry.getHost())
								           .withType(logEntry.getType())
								           .withDuration(duration)
								           .withAlert(alert)
								           .build();
						
						log.debug("Saving event data: {}", event);
						
						repository.save(event);

					}
				} catch (JsonMappingException e) {
					log.error("Error in mapping: {}", e);
				} catch (JsonProcessingException e) {
					log.error("Error in parseing:{}", e);
				}
			});
		} catch (IOException e) {
			log.error("Error in save :{}" , e);
			return false;
		}
		
		return true;

	}
}
