package com.cs.log.analyzer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.cs.log.analyzer.service.LogEventService;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class LogAnalyzerApplication implements CommandLineRunner{

	@Autowired
	private LogEventService logEventService;
	
	public static void main(String[] args) {
		log.info("*****Starting LogAnalyzerApplication*****");
		
		SpringApplication logEventApp = new SpringApplication(LogAnalyzerApplication.class);
		logEventApp.run(args);
	}

	@Override
	public void run(String... args) throws Exception {
	
		if(args ==null || args.length !=1) {
			log.error("Input log file not provided Please check the appliation argument");
			throw new IllegalArgumentException("Input log file not provided for parsing .....");
		}
		
		log.info("*****Started Parsing the Server Logs*****");
		logEventService.parseLogAndPersistToDb(args[0]);
		
	}

}
