package com.cs.log.analyzer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cs.log.analyzer.exception.RecordNotFoundException;
import com.cs.log.analyzer.modal.Event;
import com.cs.log.analyzer.service.LogEventService;

@RestController
public class LogEventController {

	@Autowired
	private LogEventService logEventService;

	@GetMapping("logEvents/{id}")
	public ResponseEntity<Event> getLogEventById(@PathVariable String id) {

		Optional<Event> event = logEventService.getLogEventById(id);

		if (!event.isPresent()) {
			throw new RecordNotFoundException("Invalid Log event id : " + id);
		}

		return new ResponseEntity<>(event.get(), HttpStatus.OK);
	}

	@GetMapping("LogEvents")
	public ResponseEntity<List<Event>> getAllLogEvents() {

		List<Event> event = logEventService.getLogEvents();

		if (event.isEmpty()) {
			throw new RecordNotFoundException("No record found ");
		}

		return new ResponseEntity<>(event, HttpStatus.OK);
	}

	@GetMapping("logEvents/flagged")
	public ResponseEntity<List<Event>> getFlaggedLogEvents() {

		List<Event> flaggedLogEvents = logEventService.getFlaggedLogEvents();

		if (flaggedLogEvents.isEmpty()) {
			throw new RecordNotFoundException("No record found ");
		}

		return new ResponseEntity<>(flaggedLogEvents, HttpStatus.OK);
	}

}
