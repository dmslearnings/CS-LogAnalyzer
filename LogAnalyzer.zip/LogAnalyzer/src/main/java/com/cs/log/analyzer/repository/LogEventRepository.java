package com.cs.log.analyzer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cs.log.analyzer.modal.Event;

public interface LogEventRepository extends JpaRepository<Event, String> {

	@Query("FROM Event WHERE alert = ?1")
	List<Event> findByAlertValue(boolean alert);

}
